package han;

import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;

import org.junit.Test;

public class HanTest {

	@Test
	public void testEncoding() {
		String encoding = System.getProperty("file.encoding");
		if ("EUC_KR".equals(encoding)) {
			byte[] bytes = new byte[]{
					0xffffffC7,
					0xffffffd1,
					0xffffffb1,
					0xffffffdb};
			String test = new String(bytes);
			assertThat(test.length(), is(2));
			assertThat(bytes.length, is(4));
		} else {
			assertThat(encoding, is("UTF-8"));
			byte[] bytes = new byte[]{
					0xffffffED,
					0xffffff95,
					0xffffff9c,
					0xffffffea,
					0xffffffb8,
					0xffffff80
					};
			String test = new String(bytes);
			assertThat(test.length(), is(2));
			assertThat(bytes.length, is(6));
		};
	}
}
